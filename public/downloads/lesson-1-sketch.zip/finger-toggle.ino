// finger-toggle.ino
// One button press closes the finger. The next press opens it.

const int buttonPin = 2; // Button leg. The other leg goes to GND.
const int motorPin = 9;  // Motor driver input. HIGH closes the finger.

bool fingerClosed = false;  // false means the finger is open
bool buttonWasDown = false; // remembers the last reading so we toggle once per press

void setup() {
  pinMode(buttonPin, INPUT_PULLUP); // HIGH at rest, LOW when the button connects the pin to ground
  pinMode(motorPin, OUTPUT);        // this pin drives the motor
  digitalWrite(motorPin, LOW);      // start with the finger open
}

void loop() {
  bool buttonDown = digitalRead(buttonPin) == LOW; // pressed reads LOW because of INPUT_PULLUP

  if (buttonDown && !buttonWasDown) { // the button just went down
    fingerClosed = !fingerClosed;      // flip between open and closed
    digitalWrite(motorPin, fingerClosed ? HIGH : LOW); // HIGH closes, LOW opens
  }

  buttonWasDown = buttonDown; // store this reading for the next loop
  delay(20);                   // wait so a bouncing contact counts as one press
}
